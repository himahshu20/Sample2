<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Campaign; 
use Illuminate\Support\Facades\Auth;

class CampaignController extends Controller
{
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'subject' => 'required|string|max:255',
            'body' => 'required',
            'data' => 'required|array',
            'data.*.name' => 'required|string|max:255',
            'data.*.email' => 'required|email|max:255',
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $campaign = Campaign::create([
            'user_id' => Auth::id(), // Store the ID of the logged-in user
            'name' => $request->name,
            'subject' => $request->subject,
            'body' => $request->body,
            'data' => json_encode($request->data), // Store the CSV data as JSON
        ]);
        
        return response()->json([
            'message' => 'Campaign created successfully',
            'campaign' => $request->name,
            'data' => $request->data,
        ], 201);
    }
}
